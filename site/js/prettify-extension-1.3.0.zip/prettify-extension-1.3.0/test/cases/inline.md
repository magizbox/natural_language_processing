Some inline javascript`var foo = bar`
