Here's some github code style

```js
var foo = bar;

function bazinga() {
  return 'bazinga!!';
}
```
