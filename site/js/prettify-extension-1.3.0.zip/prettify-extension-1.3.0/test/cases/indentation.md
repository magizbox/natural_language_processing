Here's a simple hello world in javascript:

    alert('Hello World!');

